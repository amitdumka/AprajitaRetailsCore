module.exports = {
    plugins: {
        autoprefixer: { grid: true }
    }
}