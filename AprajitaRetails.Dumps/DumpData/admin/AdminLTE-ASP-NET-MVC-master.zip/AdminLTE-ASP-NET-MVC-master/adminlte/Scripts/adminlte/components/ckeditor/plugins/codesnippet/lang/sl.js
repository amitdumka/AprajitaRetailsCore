﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","sl",{button:"Vstavi odsek kode",codeContents:"Vsebina kode",emptySnippetError:"Odsek kode ne more biti prazen.",language:"Jezik",title:"Odsek kode",pathName:"odsek kode"});