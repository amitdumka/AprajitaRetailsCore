# Org.OpenAPITools.Model.InstanceStatusLink
Status information link
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Label** | **string** | Link caption for the button | [optional] 
**Link** | **string** | Reference URL instead of method | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

