# Org.OpenAPITools.Model.ChatUpdate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Old** | [**Chat**](Chat.md) |  | [optional] 
**New** | [**Chat**](Chat.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

