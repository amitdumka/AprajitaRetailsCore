# Org.OpenAPITools.Model.ClearMessagesQueueStatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Message** | **string** | Messages queue clear status | [optional] 
**MessageTextsExample** | **List&lt;string&gt;** | Content of the first hundred messages from the cleaned queue | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

