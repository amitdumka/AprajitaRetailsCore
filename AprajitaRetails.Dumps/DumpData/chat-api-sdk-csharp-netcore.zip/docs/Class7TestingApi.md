# Org.OpenAPITools.Api.Class7TestingApi

All URIs are relative to *https://api.chat-api.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**InstanceStatuses**](Class7TestingApi.md#instancestatuses) | **GET** /instanceStatuses | Returns instance status changes history.
[**WebhookStatuses**](Class7TestingApi.md#webhookstatuses) | **GET** /webhookStatus | Returns webhook status for message.


<a name="instancestatuses"></a>
# **InstanceStatuses**
> Statuses InstanceStatuses (int? minTime = null, int? maxTime = null)

Returns instance status changes history.

Requires enable \"instanceStatuses\" option for collecting data.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class InstanceStatusesExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.chat-api.com";
            // Configure API key authorization: instanceId
            config.AddApiKey("instanceId", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("instanceId", "Bearer");
            // Configure API key authorization: token
            config.AddApiKey("token", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("token", "Bearer");

            var apiInstance = new Class7TestingApi(config);
            var minTime = 946684800;  // int? | Filter statuses received after specified date. Example: 946684800. (optional) 
            var maxTime = 946684800;  // int? | Filter statuses received before specified date. Example: 946684800. (optional) 

            try
            {
                // Returns instance status changes history.
                Statuses result = apiInstance.InstanceStatuses(minTime, maxTime);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling Class7TestingApi.InstanceStatuses: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **minTime** | **int?**| Filter statuses received after specified date. Example: 946684800. | [optional] 
 **maxTime** | **int?**| Filter statuses received before specified date. Example: 946684800. | [optional] 

### Return type

[**Statuses**](Statuses.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="webhookstatuses"></a>
# **WebhookStatuses**
> WebhookStatus WebhookStatuses (string msgId)

Returns webhook status for message.

Requires enable \"webhookStatuses\" option for collecting data.

### Example
```csharp
using System.Collections.Generic;
using System.Diagnostics;
using Org.OpenAPITools.Api;
using Org.OpenAPITools.Client;
using Org.OpenAPITools.Model;

namespace Example
{
    public class WebhookStatusesExample
    {
        public static void Main()
        {
            Configuration config = new Configuration();
            config.BasePath = "https://api.chat-api.com";
            // Configure API key authorization: instanceId
            config.AddApiKey("instanceId", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("instanceId", "Bearer");
            // Configure API key authorization: token
            config.AddApiKey("token", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // config.AddApiKeyPrefix("token", "Bearer");

            var apiInstance = new Class7TestingApi(config);
            var msgId = false_17472822486@c.us_DF38E6A25B42CC8CCE57EC40F;  // string | Message ID. Example: false_17472822486@c.us_DF38E6A25B42CC8CCE57EC40F.

            try
            {
                // Returns webhook status for message.
                WebhookStatus result = apiInstance.WebhookStatuses(msgId);
                Debug.WriteLine(result);
            }
            catch (ApiException  e)
            {
                Debug.Print("Exception when calling Class7TestingApi.WebhookStatuses: " + e.Message );
                Debug.Print("Status Code: "+ e.ErrorCode);
                Debug.Print(e.StackTrace);
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **msgId** | **string**| Message ID. Example: false_17472822486@c.us_DF38E6A25B42CC8CCE57EC40F. | 

### Return type

[**WebhookStatus**](WebhookStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

