# Org.OpenAPITools.Model.Messages
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_Messages** | [**List&lt;Message&gt;**](Message.md) |  | [optional] 
**LastMessageNumber** | **int** | next query should be /messages?lastMessageNumber&#x3D;199 | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

