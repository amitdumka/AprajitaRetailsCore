# Org.OpenAPITools.Model.InstanceStatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccountStatus** | **string** | Instance Status | [optional] 
**QrCode** | **byte[]** | Base64-encoded contents of the QR code | [optional] 
**StatusData** | [**InstanceStatusStatusData**](InstanceStatusStatusData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

