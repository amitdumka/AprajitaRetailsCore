# Org.OpenAPITools.Model.ClearActionsQueueStatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Message** | **string** | Actions queue clear status | [optional] 
**ActionsExample** | **List&lt;string&gt;** | Type of the first hundred actions from the cleaned queue | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

