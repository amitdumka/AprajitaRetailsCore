# Org.OpenAPITools.Model.PhoneProp
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Phone** | **int** | **Required if chatId is not set**  A phone number starting with the country code. You do not need to add your number.   USA example: 17472822486. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

