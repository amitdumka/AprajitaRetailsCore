# Org.OpenAPITools.Model.Chats
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Dialogs** | [**List&lt;Chat&gt;**](Chat.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

