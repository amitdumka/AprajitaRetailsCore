# Org.OpenAPITools.Model.CreateGroupStatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Created** | **bool** |  | [optional] 
**Message** | **string** | Group creation status | [optional] 
**ChatId** | **string** | Created group id | [optional] 
**GroupInviteLink** | **string** | Link invitation to the group | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

