# Org.OpenAPITools.Model.GroupParticipantStatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Add** | **bool** |  | [optional] 
**Message** | **string** | Status of adding participant to group | [optional] 
**GroupId** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

