# Org.OpenAPITools.Model.InstanceStatusAction
Action for change status
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Act** | **string** | Method name | [optional] 
**Label** | **string** | Action caption for the button | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

