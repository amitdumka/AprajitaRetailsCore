# Org.OpenAPITools.Model.OutboundMessage
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** | message id in queue | [optional] 
**Body** | **string** | text message in queue | [optional] 
**Type** | **string** | type of the message in queue | [optional] 
**LastTry** | **int** | Last try time to send a message | [optional] 
**Metadata** | [**Object**](.md) | Additional message data | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

