# Org.OpenAPITools.Model.WebhookStatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MsgId** | **string** | message id | [optional] 
**Time** | **string** | creation date | [optional] 
**Status** | **string** | status name (\&quot;sent\&quot;, \&quot;not sent\&quot;, \&quot;queued\&quot;) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

