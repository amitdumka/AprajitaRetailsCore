# Org.OpenAPITools.Model.SetWebhookStatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Set** | **bool** | Flag indicating that the current request has changed webhook | [optional] 
**Message** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

