# Org.OpenAPITools.Model.BanSettings
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BanPhoneMask** | **string** |  | 
**PreBanMessage** | **string** |  | 
**Set** | **bool** | Flag indicating that the current request has changed ban settings | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

