# Org.OpenAPITools.Model.InstanceStatusStatusDataActions
Actions that can be applied to change the status
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Expiry** | [**InstanceStatusAction**](InstanceStatusAction.md) |  | [optional] 
**Retry** | [**InstanceStatusAction**](InstanceStatusAction.md) |  | [optional] 
**Logout** | [**InstanceStatusAction**](InstanceStatusAction.md) |  | [optional] 
**Takeover** | [**InstanceStatusAction**](InstanceStatusAction.md) |  | [optional] 
**LearnMore** | [**InstanceStatusLink**](InstanceStatusLink.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

