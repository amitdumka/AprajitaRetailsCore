# Org.OpenAPITools.Model.OutboundActions
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TotalActions** | **int** | Total number of actions in the queue | [optional] 
**First100** | [**List&lt;OutboundAction&gt;**](OutboundAction.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

