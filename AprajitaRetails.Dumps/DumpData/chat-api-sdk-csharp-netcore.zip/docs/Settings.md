# Org.OpenAPITools.Model.Settings
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**WebhookUrl** | **string** |  | [optional] 
**AckNotificationsOn** | **bool?** |  | [optional] 
**ChatUpdateOn** | **bool?** |  | [optional] 
**VideoUploadOn** | **bool?** |  | [optional] 
**Proxy** | **string** |  | [optional] 
**GuaranteedHooks** | **bool?** |  | [optional] 
**IgnoreOldMessages** | **bool?** |  | [optional] 
**ProcessArchive** | **bool?** |  | [optional] 
**InstanceStatuses** | **bool?** |  | [optional] 
**WebhookStatuses** | **bool?** |  | [optional] 
**StatusNotificationsOn** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

