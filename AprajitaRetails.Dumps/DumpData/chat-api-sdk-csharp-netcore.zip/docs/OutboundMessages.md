# Org.OpenAPITools.Model.OutboundMessages
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TotalMessages** | **int** | Total number of messages in the queue | [optional] 
**First100** | [**List&lt;OutboundMessage&gt;**](OutboundMessage.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

