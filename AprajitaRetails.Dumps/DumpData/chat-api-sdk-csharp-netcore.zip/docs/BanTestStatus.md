# Org.OpenAPITools.Model.BanTestStatus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Banned** | **bool** |  | [optional] 
**Message** | **string** |  | [optional] 
**Phone** | **string** | Test phone number | [optional] 
**BanPhoneMask** | **string** | Test regex | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

