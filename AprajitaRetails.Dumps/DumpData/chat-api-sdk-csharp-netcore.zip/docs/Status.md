# Org.OpenAPITools.Model.Status
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Date** | **string** | status date | [optional] 
**_Status** | **string** | status name (\&quot;init\&quot;, \&quot;got qr code\&quot;, \&quot;loading\&quot;, \&quot;authenticated\&quot;) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

