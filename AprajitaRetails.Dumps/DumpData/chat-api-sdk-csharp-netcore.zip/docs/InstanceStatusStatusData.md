# Org.OpenAPITools.Model.InstanceStatusStatusData
More information about instance status
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Substatus** | **string** | Instance Substatus | [optional] 
**Title** | **string** | Status title in the language of the instance | [optional] 
**Msg** | **string** | Status message in the language of the instance | [optional] 
**Submsg** | **string** | Additional status message in the language of the instance | [optional] 
**Actions** | [**InstanceStatusStatusDataActions**](InstanceStatusStatusDataActions.md) |  | [optional] 
**Reason** | **string** | The reason why the instance is in \&quot;loading\&quot; status | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

